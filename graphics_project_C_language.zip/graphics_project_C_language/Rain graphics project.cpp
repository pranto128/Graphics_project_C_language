#include<graphics.h>
int main()

{
    int gd=DETECT;
    int gm;

    initgraph(&gd,&gm,"C:\\TC\\BGI");

  for(;;)
    {
    int maxX = getmaxx();

    for(int i=0;i<maxX;i++)
    {

   //rain
       setcolor(15);
       int rx,ry,x=0,y=0;
            rx=rand()%639;
            ry=rand()%439;
            line(rx-10,ry+10,rx,ry);
            rx=rand()%539;
            ry=rand()%339;
            line(rx-10,ry+10,rx,ry);
            rx=rand()%439;
            ry=rand()%239;
            line(rx-10,ry+10,rx,ry);
            rx=rand()%539;
            ry=rand()%339;
            line(rx-10,ry+10,rx,ry);
            rx=rand()%539;
            ry=rand()%139;
            line(rx-10,ry+10,rx,ry);
            rx=rand()%839;
            ry=rand()%339;
            line(rx-10,ry+10,rx,ry);
            rx=rand()%539;
            ry=rand()%639;
            line(rx-10,ry+10,rx,ry);
            rx=rand()%239;
            ry=rand()%339;
            line(rx-10,ry+10,rx,ry);
            rx=rand()%739;
            ry=rand()%339;
            line(rx-10,ry+10,rx,ry);
            rx=rand()%1000;
            ry=rand()%400;
            line(rx-10,ry+10,rx,ry);
            x=rand()%100;
            ry=rand()%10;
            line(rx-10,ry+10,rx,ry);
            x=rand()%10;
            ry=rand()%100;
            line(rx-10,ry+10,rx,ry);
            x=rand()%210;
            ry=rand()%109;
            line(rx-10,ry+10,rx,ry);
            x=rand()%310;
            ry=rand()%210;
            line(rx-10,ry+10,rx,ry);
    //ROAD
    setcolor (15);
    line(10,390,maxX,390);


    //Car
    setcolor(15);

    rectangle(20+i,245,120+i,370);
    rectangle(120+i,320,170+i,370);

    setcolor(14);
    circle(45+i,380,10);
    circle(145+i,380,10);


    //Flying Bus

    setcolor(7);
    rectangle(0+i*5,50,50+i*5,60);

    setcolor(9);
    rectangle(100+i*5,70,150+i*5,80);

    setcolor(11);
    rectangle(200+i*5,30,250+i*5,40);

    setcolor(12);
    rectangle(300+i*5,20,350+i*5,30);

    setcolor(13);
    rectangle(-400+i*5,30,-350+i*5,40);

    setcolor(14);
    rectangle(-500+i*5,40,-450+i*5,50);

    setcolor(15);
    rectangle(-600+i*5,50,-550+i*5,60);

    setcolor(10);
    rectangle(-700+i*5,60,-650+i*5,70);


    //Plane
    setcolor(10);

    //Front area
    line(450-i,100,500-i,100);
    line(450-i,100,440-i,105);
    line(450-i,110,500-i,110);
    line(450-i,110,440-i,105);


    //Top Front Wing
    line(500-i,100,520-i,30);
    line(520-i,30,520-i,100);

    //Bottom Front Wing
    line(500-i,110,520-i,180);
    line(520-i,180,520-i,110);

    //Rear Area
    line(520-i,100,570-i,100);
    line(520-i,110,570-i,110);



    delay(20);
    cleardevice();

  }

}
    getch();
    closegraph();

}
