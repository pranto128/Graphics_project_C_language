#include <graphics.h>
#include <dos.h>
#include<stdio.h>
#include<conio.h>
int main()
{
    bool dbflag= false,closeflag=true;
    initwindow(500,500,"My Game",0, 0, dbflag, closeflag);
    char key='\0';
    int x=250,y=250;
    settextstyle(DEFAULT_FONT,HORIZ_DIR,3);
    while(1){

        if(key=='s')
        {
            circle(x,y,10);
        }
        if(key=='r')
        {
            x=x+5;
            circle(x,y,10);
        }

        if(key=='l')
        {
            x=x-5;
            circle(x,y,10);
        }

        if(key=='u')
        {
            y=y-5;
            circle(x,y,10);
        }

        if(key=='d')
        {
            y=y+5;
            circle(x,y,10);
        }
        delay(10);
        key=getch();
        cleardevice();

    }
    getch();
    //closegraph();
   return 0;
}
