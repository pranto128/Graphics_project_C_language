#include <graphics.h>
#include <dos.h>
#include<stdio.h>
#include<conio.h>
int main()
{
    bool dbflag= false,closeflag=true;
    initwindow(500,500,"My Game",0, 0, dbflag, closeflag);

    settextstyle(DEFAULT_FONT,HORIZ_DIR,3);
    int j=1;
    for(int i=10;i<200;){

        circle(250,250,i);
        delay(50);
        cleardevice();
        i=i+1*j;
        //printf("\n%d",i);
        if(i==199)
           j=-1;
        if(i==0)
           j=1;
    }
    getch();
    //closegraph();
   return 0;
}
