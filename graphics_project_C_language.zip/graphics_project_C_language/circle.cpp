#include <graphics.h>
#include <dos.h>
#include<stdio.h>
#include<conio.h>
int main()
{
    bool dbflag= false,closeflag=true;
    initwindow(500,500,"My Game",0, 0, dbflag, closeflag);

    settextstyle(DEFAULT_FONT,HORIZ_DIR,3);
    //for(int i=100;i<501;i=i+100){

        circle(250,250,100);

    //}
    getch();
    //closegraph();
   return 0;
}
