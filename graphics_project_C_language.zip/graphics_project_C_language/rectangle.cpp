#include <graphics.h>
#include <dos.h>
#include<stdio.h>
#include<conio.h>
int main()
{
    bool dbflag= false,closeflag=true;
    initwindow(500,500,"My Game",0, 0, dbflag, closeflag);

    settextstyle(DEFAULT_FONT,HORIZ_DIR,3);
    for(int i=100;i<501;i=i+100){
        /* Horizontal */
        setcolor(CYAN);
        line(0,i,500,i);
        line(0,i-1,500,i-1);
        line(0,i-2,500,i-2);
        line(0,i-3,500,i-3);
        /* Vertical */
        setcolor(RED);
        line(i,0,i,500);
        line(i-1,0,i-1,500);
        line(i-2,0,i-2,500);
        line(i-3,0,i-3,500);
    //rectangle(100,300,400,700);

    }
    getch();
    //closegraph();
   return 0;
}
