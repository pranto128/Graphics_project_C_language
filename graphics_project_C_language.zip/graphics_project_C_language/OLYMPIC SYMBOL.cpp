#include <stdio.h>
#include <graphics.h>
#include<windows.h>
//#include<dos.h>
//#include <stdlib.h>
int main()
{

int gd,gm,i;
//setbkcolor(RED);

bool dbflag= false,closeflag=true;
    initwindow(1000,800,"My Game",0, 0, dbflag, closeflag);
setbkcolor(WHITE);
//system("color 78");
//setcolor( WHITE );
while(!kbhit())
 outtextxy(0,0,"olympic symbol:::::::");
 cleardevice();

// delay(3000);
//setbkcolor(RED);

// setbkcolor(RED);
while(1)
{

  for(i=50;i<=60;i++)
 {
    // setbkcolor(RED);
     delay(200);
     setcolor(BLUE);
circle(150, 150, 1*i);
delay(200);
circle(150, 150, 1*i);
 }

for(i=50;i<=60;i++)
{
    setcolor(BLACK);
delay(200);
circle(280, 150,1*i);
delay(200);
circle(280, 150, 1*i);
}

for(i=50;i<=60;i++)
{
    setcolor(RED);
     delay(200);
circle(410, 150,1*i);
 delay(200);
circle(410, 150,1*i);
}
 for(i=50;i<=60;i++)
 {

 setcolor(YELLOW);
      delay(200);
circle(215, 200, 1*i);
 delay(200);
circle(215, 200, 1*i);
 }
 for(i=50;i<=60;i++)
 {

 setcolor(GREEN);
     delay(200);
circle(345, 200, 1*i);
delay(200);
circle(345, 200, 1*i);
 }

//cleardevice();
 }
//circle(210, 200, 60);
//circle(50, 50, 50);
//setbkcolor(GREEN);
getch();
return 0;
}
