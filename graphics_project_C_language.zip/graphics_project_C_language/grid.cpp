#include <graphics.h>
#include <dos.h>
#include<stdio.h>
#include<conio.h>
int main()
{
    bool dbflag= false,closeflag=true;
    initwindow(500,500,"My Game",0, 0, dbflag, closeflag);

    settextstyle(DEFAULT_FONT,HORIZ_DIR,3);
    while(1){
        setcolor(WHITE);
       // bar(220,235,280,265); // left,top ,right,bottom
       // setcolor(GREEN);
       // circle(i,j,2);
       // delay(50);
       for(int j=0;j<501;)
       {
           for(int i=0;i<501;)
           {
               circle(i,j,2);
               i=i+50;
           }
           j=j+50;

       }
       bar(200,200,300,300);
    }
    getch();
    //closegraph();
   return 0;
}
