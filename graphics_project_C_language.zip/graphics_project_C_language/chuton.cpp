
#include<stdio.h>
#include<graphics.h>
int main()
{

            int gdriver = DETECT, gmode, errorcode;
    initgraph(&gdriver,&gmode,"d:\\tc\\bgi");
    int i,d=0,x=50,y=340,shouldMove=1;
    int rx,ry;

{
    int maxX = getmaxx();

    for(int i=0;i<maxX;i++)
{

   //rain
       setcolor(15);
       int rx,ry,x=0,y=0;
            rx=rand()%639;
            ry=rand()%439;
            line(rx-10,ry+10,rx,ry);
            rx=rand()%539;
            ry=rand()%339;
            line(rx-10,ry+10,rx,ry);
            rx=rand()%439;
            ry=rand()%239;
            line(rx-10,ry+10,rx,ry);
            rx=rand()%539;
            ry=rand()%339;
            line(rx-10,ry+10,rx,ry);
            rx=rand()%539;
            ry=rand()%139;
            line(rx-10,ry+10,rx,ry);
            rx=rand()%839;
            ry=rand()%339;
            line(rx-10,ry+10,rx,ry);
            rx=rand()%539;
            ry=rand()%639;
            line(rx-10,ry+10,rx,ry);
            rx=rand()%239;
            ry=rand()%339;
            line(rx-10,ry+10,rx,ry);
            rx=rand()%739;
            ry=rand()%339;
            line(rx-10,ry+10,rx,ry);
            rx=rand()%1000;
            ry=rand()%400;
            line(rx-10,ry+10,rx,ry);
            x=rand()%100;
            ry=rand()%10;
            line(rx-10,ry+10,rx,ry);
            x=rand()%10;
            ry=rand()%100;
            line(rx-10,ry+10,rx,ry);
            x=rand()%210;
            ry=rand()%109;
            line(rx-10,ry+10,rx,ry);
            x=rand()%310;
            ry=rand()%210;
            line(rx-10,ry+10,rx,ry);


    //setcolor(15);
//    int i;

    line(50,250,50,450);
    line(600,250,600,450);
    line(50,450,600,450);

    line(50,250,280,250);
    line(370,250,600,250);

    for(i=0;i<20;++i)
        {
    line(330-i,20,100-i,120);
    line(100,120,100,220);
        }
    for(i=0;i<5;++i)
        {
    rectangle(130+i,130+i,300+i,220);
        }
    rectangle(140,140,295,215);
    line(192,140,192,215);
    line(245,140,245,215);

    for(i=0;i<20;++i)
        {
    line(330+i,20,550+i,120);
    line(550,120,550,220);
    line(435+i,70,330+i,120);
        }
       for(i=0;i<5;++i)
       {
    line(350+i,120,350+i,220);
    line(100,120,330,120);
       }

    for(i=0;i<5;++i)
        {
    rectangle(370+i,120+i,505+i,195+i);
        }
    rectangle(380,130,500,190);
    rectangle(380,130,440,190);
    rectangle(445,130,500,190);

    line(50,250,100,220);
    line(600,250,550,220);

    line(100,220,550,220);


    rectangle(230,400,270,450);
    rectangle(235,350,265,400);
    rectangle(245,280,255,350);
    rectangle(380,400,420,450);
    rectangle(385,350,415,400);
    rectangle(395,280,405,350);


    for(i=0;i<=10;++i)
        {
    line(330,220+i,230,280+i);
    line(330,220+i,420,280+i);
        }

    rectangle(290,330,360,450);
    //line(325,350,325,450);
    line(320,350,320,450);
    line(330,350,330,450);
    line(290,330,320,350);
    line(360,330,330,350);

    rectangle(80,300,200,370);
    rectangle(85,305,195,365);
    line(122,305,122,365);
    line(157,305,157,365);
    rectangle(445,300,570,370);
    rectangle(450,305,565,365);
    line(487,305,487,365);
    line(524,305,524,365);

    line(415,390,600,390);
    line(50,390,235,390);

    delay(20);
    cleardevice();
}
}
getchar();
return 0;
}
